CREATE TABLE loan_request_status (
  id INTEGER NOT NULL PRIMARY KEY,
  status TEXT NOT NULL
);
