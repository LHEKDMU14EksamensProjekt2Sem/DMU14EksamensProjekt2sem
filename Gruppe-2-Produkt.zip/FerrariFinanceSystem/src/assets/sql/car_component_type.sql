CREATE TABLE car_component_type (
  id INTEGER NOT NULL PRIMARY KEY,
  type TEXT NOT NULL UNIQUE
);
