CREATE TABLE car_model (
  id INTEGER NOT NULL PRIMARY KEY,
  year INTEGER NOT NULL,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  base_price NUMERIC NOT NULL
);
