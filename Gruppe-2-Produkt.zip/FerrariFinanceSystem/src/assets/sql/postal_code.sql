CREATE TABLE postal_code (
  postal_code INTEGER NOT NULL PRIMARY KEY,
  city TEXT NOT NULL
);
