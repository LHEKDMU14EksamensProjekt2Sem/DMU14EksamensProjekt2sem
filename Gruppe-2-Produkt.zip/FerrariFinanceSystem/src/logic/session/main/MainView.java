package logic.session.main;

public enum MainView {
   LOGIN, MAIN_MENU
}
