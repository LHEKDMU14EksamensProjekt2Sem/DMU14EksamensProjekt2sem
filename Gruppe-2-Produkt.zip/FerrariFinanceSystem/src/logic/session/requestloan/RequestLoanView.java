package logic.session.requestloan;

public enum RequestLoanView {
   CPR, CUSTOMER_DETAILS, REQUEST_DETAILS
}
