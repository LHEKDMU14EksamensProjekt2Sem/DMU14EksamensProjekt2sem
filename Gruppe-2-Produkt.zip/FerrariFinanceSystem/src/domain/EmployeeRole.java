package domain;

public enum EmployeeRole {
   SALESMAN, SALES_MANAGER
}
