package domain;

public enum LoanRequestStatus {
   PENDING, APPROVED, DECLINED
}
