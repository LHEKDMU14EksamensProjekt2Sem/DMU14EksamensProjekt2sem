package exceptions;

public class InvalidCpr extends Exception{

	private static final long serialVersionUID = 1L;

	public InvalidCpr() {
	}
}
